# Web Develeopment 2 Front End

This is the frontend for the Web Development 2 assigment

# Accounts

Admin: email: admin@admin.com password: password123
User: email: user@user.com password: password123

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
